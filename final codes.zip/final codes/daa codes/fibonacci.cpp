#include<bits/stdc++.h>
using namespace std;

int main()
{
	int n0=0,n1=1,n2,count;
	
	cout<<"Enter no";
	cin>>count;
	
	cout<<n0<<" "<<n1;
	
	for(int i=2;i<count;i++)
	{
		n2=n0+n1;
		
		cout<<" "<<n2;
		
		n0 = n1;
		n1 = n2;
		
	}
	return 0;
}